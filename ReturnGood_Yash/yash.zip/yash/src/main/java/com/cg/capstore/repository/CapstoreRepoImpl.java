package com.cg.capstore.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.Customer;
import com.cg.capstore.bean.Orders;
import com.cg.capstore.bean.Product;
@Repository
@Transactional
public class CapstoreRepoImpl implements ICapstoreRepo 
{
	@PersistenceContext
	EntityManager em;

	@Override
	public void returnGood(String productId) 
	{
		String orderId=(String) em.createNativeQuery("Select p.order_id from orders_product p where p.prod_id=:productid").setParameter("productid", productId).getSingleResult();
		Orders order=em.find(Orders.class, orderId);
		order.setOrderStatus("Returned");
		em.merge(order);
	}

	@Override
	public List<Product> findAllProducts() 
	{
		List<Product> list=new ArrayList<>();
		List<String> myProducts=new ArrayList<>();
		String customer_mobile_no="7500349802";
		Customer customer=em.find(Customer.class, customer_mobile_no);
		System.out.println(customer.getCustomer_mobile_no());
		String cartId=customer.getCart().getCart_id();
		System.out.println(cartId);
		
		List<String> order=em.createNativeQuery("Select p.order_id from cart_order p where p.cart_id=:cartid").setParameter("cartid", cartId).getResultList();
		for(String orderId: order)
		{
			System.out.println(orderId);
			myProducts.addAll(em.createNativeQuery("Select p.prod_id from orders_product p where p.order_id=:orderId").setParameter("orderId", orderId).getResultList());
		}
		
		for(String prodId:myProducts)
		{
			System.out.println(prodId);
			list.addAll(em.createQuery("select p from Product p where p.prod_id=:prodId").setParameter("prodId", prodId).getResultList());
		}
		
		
		return list;
	}

}
