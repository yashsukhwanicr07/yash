package com.cg.capstore.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.Product;

public interface ICapstoreRepo 
{
	public void returnGood(String productId);
	public List<Product> findAllProducts();

}
