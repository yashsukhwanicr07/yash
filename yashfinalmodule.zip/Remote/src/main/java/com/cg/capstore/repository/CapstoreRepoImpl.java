package com.cg.capstore.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.Orders;
import com.cg.capstore.bean.Product;
@Repository
@Transactional
public class CapstoreRepoImpl implements ICapstoreRepo 
{
	@PersistenceContext
	EntityManager em;

	@Override
	public void returnGood(String productId) 
	{
		String orderId=(String) em.createNativeQuery("Select p.order_id from orders_product p where p.prod_id=:productid").setParameter("productid", productId).getSingleResult();
		Orders order=em.find(Orders.class, orderId);
		order.setOrderStatus("Returned");
		em.merge(order);
	}

	@Override
	public List<Product> findAllProducts() 
	{
		Query query=em.createQuery("select p from Product p");
		List<Product> list=query.getResultList();
		return list;
	}

}
