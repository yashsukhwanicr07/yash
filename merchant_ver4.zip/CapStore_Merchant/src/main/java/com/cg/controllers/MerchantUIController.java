package com.cg.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bean.Merchant;
import com.cg.bean.Product;
import com.cg.service.ICapstoreService;
import com.google.gson.Gson;

@Controller
public class MerchantUIController 
{
	@Autowired
	ICapstoreService serviceref;
	
	

	@RequestMapping(value="/")
	public String getHomePage(ModelMap modelmap)
	{
		List<Product> list=serviceref.findAllProductsMerchant("9079296110");
		Map<String,Integer> map=new HashMap<>();
		for(Product i:list)
		{
			
			System.out.println(i.getName()+"nameeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
			System.out.println(i.getInitialQuantity()-i.getAvailableQuantity());
		map.put(i.getName(), i.getInitialQuantity()-i.getAvailableQuantity());
		}
		Gson gsonObj=new Gson();
		Map<Object,Object> map1=null;
		List<Map<Object,Object>> listOfObject=new ArrayList<Map<Object,Object>>();

		
		for(Entry<String, Integer> m:map.entrySet())
		{
			map1 = new HashMap<Object,Object>();
			System.out.println(m.getKey()+"           "+m.getValue());
			map1.put("label",m.getKey()); 
			map1.put("y", m.getValue());
			listOfObject.add(map1);

		}
		 	
			
			
		String dataPoints = gsonObj.toJson(listOfObject);

		System.out.println(dataPoints+"sssssssssssssssss");
		
		
		modelmap.addAttribute("analysis",dataPoints);	
		
		
		
		return "merchant_home";
		
	}
	
	
	@RequestMapping(value="/discount")
	public String afterDiscountHome(@ModelAttribute Product product)
	{
		System.out.println(product.getName());
		Product prod=serviceref.addDiscount(product);
		System.out.println(prod.getProdId()+","+ prod.getProdDiscount());
		return "merchant_home";
		
	}
	@RequestMapping(value="/merchantHome")
	public String merchantHome(@ModelAttribute("merchant") Merchant merchant)
	{
		Merchant merchantupdated=serviceref.changePassword(merchant);
		return "merchant_home";
		
	}
	@RequestMapping(value="/updatedProduct")
	public String updatedProductDetails(@ModelAttribute("product") Product product,@RequestParam("Id") String prodId)
	{
		Product updatedProduct=serviceref.updateProduct(product,prodId);
		return "merchant_home";
		
	}
	@RequestMapping(value="/merchant_display_products")
	public String myOrders(Model model)
	{
		List<Product> products=serviceref.findAllProductsMerchant("9079296110");
		
		model.addAttribute("prod", products);
		return "merchant_display_products";
	}
	
	
	@RequestMapping(value="/merchant_add_product")
	public String getaddCategoryPage()
	{
		return "merchant_add_product";
		
	}
	@RequestMapping(value="/merchant_change_password")
	public String getaddMerchantPage()
	{
		return "merchant_change_password";
		
	}
	@RequestMapping(value="/merchant_check_order_details")
	public String getCustomersPage()
	{
		return "merchant_check_order_details";
		
	}
	@RequestMapping(value="/merchant_delete_product")
	public String getMerchantPage(Model model)
	{
		List<Product> product=serviceref.findAllProductsMerchant("9079296110");
		model.addAttribute("products", product);
		return "merchant_delete_product";
		
	}
	@RequestMapping(value="/deleteProduct")
	public String updatedProducts(@RequestParam("id") String prodId,Model model)
	{
		serviceref.deleteProduct(prodId);
		List<Product> product=serviceref.findAllProductsMerchant("9079296110");
		model.addAttribute("products", product);
		return "merchant_delete_product";
		
	}
	@RequestMapping(value="/Success")
	public String successRegister(@ModelAttribute("product") Product product)
	{
		Random random=new Random();
		String prodId="P"+Integer.toString(random.nextInt(100));
		product.setProdId(prodId);
		System.out.println(product.getName());
		serviceref.addProduct(product);
		return "merchant_home";
		
	}
	
	@RequestMapping(value="/merchant_discounts")
	public String productDiscount()
	{
		
		
		return "merchant_discounts";
		
	}
	
	@RequestMapping(value="/merchant_update_product")
	public String updateProduct(@RequestParam("id") String prodId,Model model)
	{
		//Product product=new Product();
		model.addAttribute("prodid", prodId);
		//model.addAttribute("product", product);
		return "merchant_update_product";
		
	}
	
	
}
