package com.cg.repository;

import java.util.List;

import com.cg.bean.Merchant;
import com.cg.bean.Orders;
import com.cg.bean.Product;

public interface ICapstoreDao 
{
	public Product addProduct(Product product);
	public Product deleteProduct(String product);
	public Orders checkOrderDetails(Orders order);
	public Merchant changePassword(Merchant merchant);
	public List<Product> findAllProductsMerchant(String  merchantMobileNo);
	public Product updateProduct(Product product,String prodId);
}
