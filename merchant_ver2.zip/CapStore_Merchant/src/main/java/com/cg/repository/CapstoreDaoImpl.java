package com.cg.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Merchant;
import com.cg.bean.Orders;
import com.cg.bean.Product;

@Transactional
@Repository
public class CapstoreDaoImpl implements ICapstoreDao
{

	@PersistenceContext
	EntityManager em;
	
	@Override
	public Product addProduct(Product product) 
	{
		String merchantMobileNo="9079296110";
		em.persist(product);
		Merchant merchant=em.find(Merchant.class, merchantMobileNo);
		System.out.println(product.getProdId());
		int c=em.createNativeQuery("INSERT INTO merchant_product (prod_id,merchant_id) values(?,?)")
		.setParameter(1, product.getProdId())
		.setParameter(2, merchantMobileNo).executeUpdate();
		System.out.println("no of rows inserted"+c);
				return product;
	}

	@Override
	public Product deleteProduct(String prodId) 
	{
		Product product=em.find(Product.class, prodId);
		em.remove(product);
		return product;
	}

	@Override
	public Orders checkOrderDetails(Orders order) 
	{
		Orders order1 = em.find(Orders.class, order.getOrderId());
		return order1;
	}

	@Override
	public Merchant changePassword(Merchant merchant) 
	{
		Merchant merchant1=em.find(Merchant.class, merchant.getMerchantMobileNo());
		merchant1.setPassword(merchant.getPassword());
		em.persist(merchant1);
		return merchant1;
		
		
	}
	public List<Product> findAllProductsMerchant(String  merchantMobileNo) 
	{
		System.out.println("hello");
		System.out.println(merchantMobileNo);
		List<Product> products=new ArrayList<>();
		List<String> productIds=em.createNativeQuery("select p.prod_id from merchant_product p where p.merchant_id=:merchantId").setParameter("merchantId",merchantMobileNo ).getResultList();
		for(String i:productIds)
		{	
			System.out.println(i+"sssssssssssssssssssss");
			
			products.add(em.find(Product.class, i));
			
		}
		//System.out.println(products);
		return products;
		
	}

	@Override
	public Product updateProduct(Product product,String prodId) 
	{
		System.out.println("Inside updateprodutc");
		System.out.println(prodId);
		Product productexist=em.find(Product.class,prodId);
		System.out.println(product.getName()+","+product.getProdId());
		productexist.setName(product.getName());
		productexist.setSizes(product.getSizes());
		productexist.setAvailableQuantity(product.getAvailableQuantity());
		productexist.setProdCategory(product.getProdCategory());
		productexist.setPrice(product.getPrice());
		productexist.setProdDiscount(product.getProdDiscount());
		productexist.setProdImages(product.getProdImages());
		em.merge(productexist);
		return productexist;
		
	}
	

	

	
	
	
	
}
