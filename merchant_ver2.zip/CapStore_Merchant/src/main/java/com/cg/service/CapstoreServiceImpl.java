package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Merchant;
import com.cg.bean.Orders;
import com.cg.bean.Product;
import com.cg.repository.ICapstoreDao;
@Service
@Transactional
public class CapstoreServiceImpl implements ICapstoreService 
{
	@Autowired
	ICapstoreDao daoref;

	@Override
	public Product addProduct(Product product) 
	{
		return daoref.addProduct(product);

	}

	@Override
	public Product deleteProduct(String product) 
	{
		return daoref.deleteProduct(product);

	}

	@Override
	public Orders checkOrderDetails(Orders order) {
		return daoref.checkOrderDetails(order);
	}

	@Override
	public Merchant changePassword(Merchant merchant) 
	{
		return daoref.changePassword(merchant);
	}

	@Override
	public List<Product> findAllProductsMerchant(String  merchantMobileNo) 
	{
		return daoref.findAllProductsMerchant(merchantMobileNo);
	}

	@Override
	public Product updateProduct(Product product,String prodId) 
	{
		return daoref.updateProduct(product,prodId);
	}

}
