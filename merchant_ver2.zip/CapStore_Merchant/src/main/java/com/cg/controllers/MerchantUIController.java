package com.cg.controllers;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bean.Merchant;
import com.cg.bean.Product;
import com.cg.service.ICapstoreService;

@Controller
public class MerchantUIController 
{
	@Autowired
	ICapstoreService serviceref;
	
	

	@RequestMapping(value="/")
	public String getHomePage()
	{
		return "merchant_home";
		
	}
	@RequestMapping(value="/merchantHome")
	public String merchantHome(@ModelAttribute("merchant") Merchant merchant)
	{
		Merchant merchantupdated=serviceref.changePassword(merchant);
		return "merchant_home";
		
	}
	@RequestMapping(value="/updatedProduct")
	public String updatedProductDetails(@ModelAttribute("product") Product product,@RequestParam("Id") String prodId)
	{
		Product updatedProduct=serviceref.updateProduct(product,prodId);
		return "merchant_home";
		
	}
	@RequestMapping(value="/merchant_display_products")
	public String myOrders(Model model)
	{
		List<Product> products=serviceref.findAllProductsMerchant("9079296110");
		model.addAttribute("prod", products);
		return "merchant_display_products";
	}
	@RequestMapping(value="/merchant_add_product")
	public String getaddCategoryPage()
	{
		return "merchant_add_product";
		
	}
	@RequestMapping(value="/merchant_change_password")
	public String getaddMerchantPage()
	{
		return "merchant_change_password";
		
	}
	@RequestMapping(value="/merchant_check_order_details")
	public String getCustomersPage()
	{
		return "merchant_check_order_details";
		
	}
	@RequestMapping(value="/merchant_delete_product")
	public String getMerchantPage(Model model)
	{
		List<Product> product=serviceref.findAllProductsMerchant("9079296110");
		model.addAttribute("products", product);
		return "merchant_delete_product";
		
	}
	@RequestMapping(value="/deleteProduct")
	public String updatedProducts(@RequestParam("id") String prodId,Model model)
	{
		Product product1=serviceref.deleteProduct(prodId);
		List<Product> product=serviceref.findAllProductsMerchant("9079296110");
		model.addAttribute("products", product);
		return "merchant_delete_product";
		
	}
	@RequestMapping(value="/Success")
	public String successRegister(@ModelAttribute("product") Product product)
	{
		Random random=new Random();
		String prodId="P"+Integer.toString(random.nextInt(100));
		product.setProdId(prodId);
		System.out.println(product.getName());
		serviceref.addProduct(product);
		return "merchant_home";
		
	}
	
	@RequestMapping(value="/merchant_update_product")
	public String updateProduct(@RequestParam("id") String prodId,Model model)
	{
		//Product product=new Product();
		model.addAttribute("prodid", prodId);
		//model.addAttribute("product", product);
		return "merchant_update_product";
		
	}
	
	
}
