package com.capgemini.ui;

import java.util.HashMap;
import java.util.Scanner;

import com.capgemini.bean.Trainer;
import com.capgemini.service.FeedbackService;
import com.capgemini.util.DBUtil;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		FeedbackService serref = new FeedbackService();
		
		System.out.print("Enter Trainer Name:");
		String name=sc.next();
		System.out.print("Enter Course Name");
		String cname=sc.next();
		System.out.print("Enter Start Date");
		String date=sc.next();
		System.out.print("Enter End Date");
		String edate=sc.next();
		System.out.print("Enter Rating");
		int rating=sc.nextInt();
		
		Trainer trainer=new Trainer(name,cname,date,edate,rating);
		serref.addFeedback(trainer);
		System.out.println(serref.getTrainerList());
		
		System.out.print("Enter Rating");
		int rating1=sc.nextInt();
		
		HashMap<Integer, Trainer> obj=DBUtil.feedbackList;
		for(Trainer i:obj.values())
		{
			if(i.getRating()==rating)
			{
				System.out.println(i);
			}
}
}
	}