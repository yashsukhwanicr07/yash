package com.capgemini.dao;

import java.util.HashMap;

import com.capgemini.bean.Trainer;
import com.capgemini.util.DBUtil;

public class FeedbackDAO implements IFeedbackDAO {
	
	DBUtil util=new DBUtil();

	@Override
	public void addFeedback(Trainer trainer) {
		HashMap<Integer, Trainer> obj=DBUtil.feedbackList;
		obj.put((int) (Math.random()*1000), trainer);
	}


	@Override
	public HashMap<Integer, Trainer> getTrainerList() 
	{
		HashMap<Integer, Trainer> obj=DBUtil.feedbackList;
		return obj;
	}

	

}
