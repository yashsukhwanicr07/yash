package com.capgemini.bean;

public class Trainer {

	String name;
	String courseName;
	String startDate;
	String endDate;
	int rating ;

	public Trainer(String name, String courseName, String startDate, String endDate, int rating) 
	{
		this.name = name;
		this.courseName = courseName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.rating = rating;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	
	@Override
	public String toString() {
		return "Trainer [name=" + name + ", courseName=" + courseName
				+ ", startDate=" + startDate + ", endDate=" + endDate
				+ ", rating=" + rating + "]\n";
	}
}
