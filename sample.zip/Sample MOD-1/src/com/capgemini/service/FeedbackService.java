package com.capgemini.service;
import java.util.HashMap;

import com.capgemini.bean.Trainer;
import com.capgemini.dao.FeedbackDAO;
import com.capgemini.dao.IFeedbackDAO;

public class FeedbackService implements IFeedbackService {
	 IFeedbackDAO daoref=new  FeedbackDAO();

	@Override
	public void addFeedback(Trainer trainer) {
		// TODO Auto-generated method stub
		 daoref.addFeedback(trainer);
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		// TODO Auto-generated method stub
		return daoref.getTrainerList();
	}

}
