package com.capgemini.service;

import java.util.HashMap;

import com.capgemini.bean.Trainer;

public interface IFeedbackService 
{
	public void addFeedback(Trainer trainer);
	public HashMap<Integer,Trainer> getTrainerList();

	

}
